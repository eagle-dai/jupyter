///////////////////////////////////////////////////////////////////////////////////////////////
// �嵥C.5 TemplateDispatcher��ģ�� - TemplateDispatcher.hpp

#pragma once

#include "messaging_queue.hpp"

namespace messaging
{
    template<typename PreviousDispatcher, typename Msg, typename Func>
    class TemplateDispatcher
    {
        queue* q;
        PreviousDispatcher* prev;
        Func f;
        bool chained;

        template<typename Dispatcher, typename OtherMsg, typename OtherFunc>
        friend class TemplateDispatcher;  // �����ػ���TemplateDispatcher����ʵ��������Ԫ��

        void wait_and_dispatch()
        {
            for (;;)
            {
                auto msg = q->wait_and_pop();
                if (dispatch(msg)) { // 1 �����Ϣ�������󣬻�����ѭ��
                    break;
                }
            }
        }

        bool dispatch(std::shared_ptr<message_base> const& msg)
        {
            if (auto wrapper = dynamic_cast<wrapped_message<Msg>*>(msg.get()))  // 2 �����Ϣ���ͣ����ҵ��ú���
            {
                f(wrapper->contents);
                return true;
            }
            return prev->dispatch(msg);  // 3 ���ӵ�֮ǰ�ĵ�������
        }

    public:
        TemplateDispatcher(TemplateDispatcher const&) = delete;
        TemplateDispatcher& operator=(TemplateDispatcher const&) = delete;

        TemplateDispatcher(TemplateDispatcher&& other) :
            q(other.q), prev(other.prev), f(std::move(other.f)),
            chained(other.chained)
        {
            other.chained = true;
        }
        TemplateDispatcher(queue* q_, PreviousDispatcher* prev_, Func&& f_) :
            q(q_), prev(prev_), f(std::forward<Func>(f_)), chained(false)
        {
            prev_->chained = true;
        }

        template<typename OtherMsg, typename OtherFunc>
        TemplateDispatcher<TemplateDispatcher, OtherMsg, OtherFunc>
            handle(OtherFunc&& of)  // 4 ������������������
        {
            return TemplateDispatcher<
                TemplateDispatcher, OtherMsg, OtherFunc>(
                    q, this, std::forward<OtherFunc>(of));
        }

        ~TemplateDispatcher() noexcept(false)  // 5 �����������Ҳ��noexcept(false)��
        {
            if (!chained)
            {
                wait_and_dispatch();
            }
        }
    };
} // namespace messaging
