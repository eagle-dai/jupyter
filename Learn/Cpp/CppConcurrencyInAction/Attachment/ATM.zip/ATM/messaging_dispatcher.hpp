///////////////////////////////////////////////////////////////////////////////////////////////
// �嵥C.4 dispatcher�� - messaging_dispatcher.hpp

#pragma once

#include <memory>
#include "messaging_queue.hpp"
#include "TemplateDispatcher.hpp"

namespace messaging
{
    class close_queue  // ���ڹرն��е���Ϣ
    {};

    class dispatcher
    {
        queue* q;
        bool chained;

        template<typename Dispatcher,
            typename Msg,
            typename Func>  // ����TemplateDispatcherʵ�������ڲ���Ա
            friend class TemplateDispatcher;

        void wait_and_dispatch()
        {
            for (;;)  // 1 ѭ�����ȴ�������Ϣ
            {
                auto msg = q->wait_and_pop();
                dispatch(msg);
            }
        }

        bool dispatch(  // 2 dispatch()����close_queue��Ϣ��Ȼ���׳�
            std::shared_ptr<message_base> const& msg)
        {
            if (dynamic_cast<wrapped_message<close_queue>*>(msg.get()))
            {
                throw close_queue();
            }
            return false;
        }

    public:
        dispatcher(dispatcher const&) = delete;  // dispatcherʵ�����ܱ�����
        dispatcher& operator=(dispatcher const&) = delete;

        dispatcher(dispatcher&& other) :  // dispatcherʵ�������ƶ�
            q(other.q), chained(other.chained)
        {
            other.chained = true;  // Դ���ܵȴ���Ϣ
        }

        explicit dispatcher(queue* q_) :
            q(q_), chained(false)
        {}

        template<typename Message, typename Func>
        TemplateDispatcher<dispatcher, Message, Func> handle(Func&& f)  // 3 ʹ��TemplateDispatcher����ָ�����͵���Ϣ
        {
            return TemplateDispatcher<dispatcher, Message, Func>(q, this, std::forward<Func>(f));
        }

        ~dispatcher() noexcept(false)  // 4 �����������ܻ��׳��쳣
        {
            if (!chained)
            {
                wait_and_dispatch();
            }
        }
    };
} // namespace messaging
